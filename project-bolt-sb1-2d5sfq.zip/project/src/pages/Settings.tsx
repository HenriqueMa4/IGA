import React from 'react';
import { Save } from 'lucide-react';

export default function Settings() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">System Settings</h1>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6">
          <h2 className="text-lg font-semibold mb-6">Certification Settings</h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">
                Default Certification Duration (Days)
              </label>
              <input
                type="number"
                defaultValue={30}
                className="w-full max-w-xs px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Reminder Frequency
              </label>
              <select className="w-full max-w-xs px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option>Daily</option>
                <option>Weekly</option>
                <option>Bi-weekly</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Auto-revoke on Campaign Completion
              </label>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2">
                  <input type="radio" name="auto-revoke" defaultChecked />
                  <span>Yes</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="radio" name="auto-revoke" />
                  <span>No</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t">
          <h2 className="text-lg font-semibold mb-6">Approval Workflow</h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">
                Default Approval Levels
              </label>
              <select className="w-full max-w-xs px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option>1 Level</option>
                <option>2 Levels</option>
                <option>3 Levels</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Auto-approve Low-risk Access
              </label>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2">
                  <input type="radio" name="auto-approve" />
                  <span>Yes</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="radio" name="auto-approve" defaultChecked />
                  <span>No</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t flex justify-end">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2">
            <Save className="w-5 h-5" />
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
}