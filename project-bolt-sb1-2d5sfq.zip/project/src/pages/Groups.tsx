import React, { useState } from 'react';
import { Plus, Users, Settings, Trash2, AlertCircle, CheckCircle, XCircle, Network, ArrowRightLeft, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Group } from '../types';
import { useAuthStore } from '../store/useAuthStore';
import GroupModal from '../components/GroupModal';
import GroupApprovalModal from '../components/GroupApprovalModal';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';

export default function Groups() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [showModal, setShowModal] = useState(false);
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<Group | undefined>();

  // Regular groups
  const mockGroups: Group[] = [
    {
      id: '1',
      name: 'Finance Team',
      description: 'Access to financial systems and reports',
      members: ['sarah@example.com', 'john@example.com'],
      approvers: ['manager@example.com'],
      status: 'active',
      adIntegration: {
        isIntegrated: true,
        adGroupName: 'FIN_TEAM_01',
        lastSync: '2024-03-20'
      },
      approvalStatus: {
        requiredApprovals: 2,
        approvedBy: [
          { adminId: '1', adminName: 'Admin 1', date: '2024-03-15' },
          { adminId: '2', adminName: 'Admin 2', date: '2024-03-16' }
        ],
        rejectedBy: []
      },
      createdBy: {
        id: '1',
        name: 'Admin 1',
        date: '2024-03-15'
      }
    },
    // ... other groups remain the same
  ];

  // Pending AD groups that need to be imported and approved
  const pendingAdGroups = [
    {
      id: 'ad1',
      name: 'Sales Team',
      adGroupName: 'SALES_TEAM_01',
      memberCount: 15,
      lastModified: '2024-03-19',
      description: 'Sales department access group from Active Directory'
    },
    {
      id: 'ad2',
      name: 'IT Support',
      adGroupName: 'IT_SUPPORT_01',
      memberCount: 8,
      lastModified: '2024-03-20',
      description: 'IT support team access group from Active Directory'
    }
  ];

  const handleCreateGroup = (groupData: Partial<Group>) => {
    const newGroup: Group = {
      ...groupData as Group,
      id: Math.random().toString(36).substr(2, 9),
      status: 'pending',
      approvalStatus: {
        requiredApprovals: 2,
        approvedBy: [],
        rejectedBy: []
      },
      createdBy: {
        id: user?.id || '',
        name: user?.name || '',
        date: new Date().toISOString().split('T')[0]
      }
    };
    toast.success('Group created successfully');
    console.log('Create group:', newGroup);
  };

  const handleEditGroup = (groupData: any) => {
    toast.success('Group updated successfully');
    console.log('Edit group:', groupData);
  };

  const handleDeleteGroup = (groupId: string) => {
    toast.success('Group deleted successfully');
    console.log('Delete group:', groupId);
  };

  const handleApprove = (groupId: string) => {
    if (!user) return;
    
    toast.success('Group approved successfully');
    console.log('Approve group:', {
      groupId,
      adminId: user.id,
      adminName: user.name,
      date: new Date().toISOString().split('T')[0]
    });
  };

  const handleReject = (groupId: string, reason: string) => {
    if (!user) return;
    
    toast.error('Group rejected');
    console.log('Reject group:', {
      groupId,
      adminId: user.id,
      adminName: user.name,
      date: new Date().toISOString().split('T')[0],
      reason
    });
  };

  const handleImportAdGroup = (adGroupId: string) => {
    toast.success('AD Group imported successfully');
    console.log('Import AD group:', adGroupId);
  };

  const openEditModal = (group: Group) => {
    setSelectedGroup(group);
    setShowModal(true);
  };

  const openApprovalModal = (group: Group) => {
    setSelectedGroup(group);
    setShowApprovalModal(true);
  };

  const getStatusBadge = (group: Group) => {
    switch (group.status) {
      case 'active':
        return (
          <span className="flex items-center gap-1 text-green-600 bg-green-50 px-2 py-1 rounded-full text-sm">
            <CheckCircle className="w-4 h-4" />
            Active
          </span>
        );
      case 'pending':
        return (
          <span className="flex items-center gap-1 text-yellow-600 bg-yellow-50 px-2 py-1 rounded-full text-sm">
            <AlertCircle className="w-4 h-4" />
            Pending Approval ({group.approvalStatus.approvedBy.length}/{group.approvalStatus.requiredApprovals})
          </span>
        );
      case 'rejected':
        return (
          <span className="flex items-center gap-1 text-red-600 bg-red-50 px-2 py-1 rounded-full text-sm">
            <XCircle className="w-4 h-4" />
            Rejected
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold">Groups</h1>
          <button
            onClick={() => {
              setSelectedGroup(undefined);
              setShowModal(true);
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700"
          >
            <Plus className="w-5 h-5" />
            New Group
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <AnimatePresence>
                {mockGroups.map((group) => (
                  <motion.div
                    key={group.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="p-4 border rounded-lg hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <Users className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-medium">{group.name}</h3>
                          <p className="text-sm text-gray-600">{group.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {group.status === 'pending' && (
                          <button 
                            onClick={() => openApprovalModal(group)}
                            className="px-3 py-1 text-blue-600 hover:bg-blue-50 rounded-lg text-sm"
                          >
                            Review
                          </button>
                        )}
                        <button 
                          onClick={() => navigate(`/groups/${group.id}`)}
                          className="p-1 hover:bg-gray-100 rounded-lg"
                        >
                          <Settings className="w-4 h-4 text-gray-600" />
                        </button>
                        <button 
                          onClick={() => handleDeleteGroup(group.id)}
                          className="p-1 hover:bg-gray-100 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4 text-gray-600" />
                        </button>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span>{group.members.length} members</span>
                        <span>{group.approvers.length} approvers</span>
                      </div>
                      <div className="flex items-center justify-between">
                        {getStatusBadge(group)}
                        {group.adIntegration?.isIntegrated && (
                          <div className="flex items-center gap-1 text-gray-600 bg-gray-100 px-2 py-1 rounded-full text-sm">
                            <Network className="w-4 h-4" />
                            <span>AD Sync</span>
                          </div>
                        )}
                      </div>
                      {group.adIntegration?.isIntegrated && (
                        <p className="text-xs text-gray-500 mt-1">
                          AD Group: {group.adIntegration.adGroupName}
                        </p>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Pending AD Groups Section */}
      <div>
        <div className="flex items-center gap-2 mb-6">
          <Network className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold">Pending AD Groups</h2>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <AnimatePresence>
                {pendingAdGroups.map((group) => (
                  <motion.div
                    key={group.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="p-4 border rounded-lg hover:shadow-md transition-shadow bg-gray-50"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <ArrowRightLeft className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-medium">{group.name}</h3>
                          <p className="text-sm text-gray-600">{group.description}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleImportAdGroup(group.id)}
                        className="px-3 py-1 text-blue-600 hover:bg-blue-50 rounded-lg text-sm flex items-center gap-1"
                      >
                        <Plus className="w-4 h-4" />
                        Import
                      </button>
                    </div>
                    
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span>{group.memberCount} members</span>
                        <span>Last modified: {group.lastModified}</span>
                      </div>
                      <p className="text-xs text-gray-500">
                        AD Group: {group.adGroupName}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      <GroupModal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setSelectedGroup(undefined);
        }}
        onSubmit={selectedGroup ? handleEditGroup : handleCreateGroup}
        group={selectedGroup}
      />

      {selectedGroup && (
        <GroupApprovalModal
          isOpen={showApprovalModal}
          onClose={() => {
            setShowApprovalModal(false);
            setSelectedGroup(undefined);
          }}
          group={selectedGroup}
          onApprove={handleApprove}
          onReject={handleReject}
        />
      )}
    </div>
  );
}