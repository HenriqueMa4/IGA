import React from 'react';
import { Shield, Clock } from 'lucide-react';

export default function MyAccess() {
  const mockAccess = [
    {
      id: '1',
      group: 'Finance Team',
      grantedDate: '2024-01-15',
      expiryDate: '2024-12-31',
      status: 'active',
    },
    {
      id: '2',
      group: 'HR Department',
      grantedDate: '2024-02-01',
      expiryDate: '2024-12-31',
      status: 'active',
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">My Access</h1>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6">
          <div className="space-y-4">
            {mockAccess.map((access) => (
              <div key={access.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Shield className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">{access.group}</h3>
                      <p className="text-sm text-gray-600">
                        Granted: {access.grantedDate}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>Expires: {access.expiryDate}</span>
                    </div>
                    <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                      Active
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6 flex justify-center">
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2">
          Request New Access
        </button>
      </div>
    </div>
  );
}