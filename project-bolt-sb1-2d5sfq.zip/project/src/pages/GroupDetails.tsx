import React, { useState } from 'react';
import { 
  Users2, 
  UserCog, 
  Settings, 
  XCircle, 
  Users,
  ArrowDown,
  Plus,
  Network,
  User,
  Clock,
  CheckCircle,
  AlertCircle,
  Shield,
  Calendar,
  Mail,
  ArrowLeft
} from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { Group } from '../types';
import { motion } from 'framer-motion';
import ApprovalStepModal from '../components/ApprovalStepModal';
import toast from 'react-hot-toast';

interface ApprovalStep {
  id: string;
  type: 'AND' | 'OR';
  approvers: string[];
  name: string;
  connectionType?: 'AND' | 'AFTER';
}

const mockGroup: Group = {
  id: '1',
  name: 'Finance Team',
  description: 'Access to financial systems and reports',
  members: ['sarah@example.com', 'john@example.com', 'mike@example.com'],
  approvers: ['manager@example.com'],
  status: 'active',
  adIntegration: {
    isIntegrated: true,
    adGroupName: 'FIN_TEAM_01',
    lastSync: '2024-03-20'
  },
  approvalStatus: {
    requiredApprovals: 2,
    approvedBy: [
      { adminId: '1', adminName: 'Admin 1', date: '2024-03-15' },
      { adminId: '2', adminName: 'Admin 2', date: '2024-03-16' }
    ],
    rejectedBy: []
  },
  createdBy: {
    id: '1',
    name: 'Admin 1',
    date: '2024-03-15'
  }
};

const mockPendingRequests = [
  {
    id: '1',
    user: 'alice@example.com',
    requestDate: '2024-03-20',
    status: 'pending',
    justification: 'Need access for financial reporting'
  },
  {
    id: '2',
    user: 'bob@example.com',
    requestDate: '2024-03-19',
    status: 'pending',
    justification: 'Required for quarterly audit'
  }
];

const mockApprovalSteps: ApprovalStep[] = [
  {
    id: '1',
    name: 'Direct Management',
    type: 'AND',
    approvers: ['manager1@example.com', 'manager2@example.com'],
    connectionType: 'AND'
  },
  {
    id: '2',
    name: 'Security Review',
    type: 'OR',
    approvers: ['security@example.com'],
    connectionType: 'AFTER'
  }
];

export default function GroupDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'details' | 'members' | 'pending' | 'approval-flow'>('details');
  const [showModal, setShowModal] = useState(false);
  const [editingStep, setEditingStep] = useState<ApprovalStep | undefined>();

  const handleAddStep = (stepData: Omit<ApprovalStep, 'id'>) => {
    const newStep = {
      ...stepData,
      id: Math.random().toString(36).substr(2, 9)
    };
    toast.success('Approval step added successfully');
    console.log('New step:', newStep);
  };

  const handleEditStep = (stepData: Omit<ApprovalStep, 'id'>) => {
    if (!editingStep) return;
    toast.success('Approval step updated successfully');
    console.log('Updated step:', { ...stepData, id: editingStep.id });
  };

  const handleDeleteStep = (stepId: string) => {
    toast.success('Approval step deleted successfully');
    console.log('Delete step:', stepId);
  };

  const handleApproveRequest = (requestId: string) => {
    toast.success('Request approved successfully');
    console.log('Approve request:', requestId);
  };

  const handleRejectRequest = (requestId: string) => {
    toast.error('Request rejected');
    console.log('Reject request:', requestId);
  };

  const tabs = [
    { id: 'details', label: 'Details', icon: Shield },
    { id: 'members', label: 'Members', icon: Users },
    { id: 'pending', label: 'Pending Requests', icon: Clock },
    { id: 'approval-flow', label: 'Approval Flow', icon: Users2 }
  ];

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <button
          onClick={() => navigate('/groups')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Groups
        </button>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{mockGroup.name}</h1>
              <p className="text-gray-600">{mockGroup.description}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {mockGroup.adIntegration?.isIntegrated && (
              <div className="flex items-center gap-1 text-gray-600 bg-gray-100 px-3 py-1.5 rounded-full text-sm">
                <Network className="w-4 h-4" />
                <span>AD Sync</span>
              </div>
            )}
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Edit Group
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="border-b">
          <div className="flex">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6">
          {activeTab === 'details' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Group Information</h3>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Created by</p>
                    <p>{mockGroup.createdBy.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Created on</p>
                    <p>{mockGroup.createdBy.date}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Status</p>
                    <div className="flex items-center gap-1 text-green-600">
                      <CheckCircle className="w-4 h-4" />
                      <span>Active</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Members</p>
                    <p>{mockGroup.members.length} members</p>
                  </div>
                </div>
              </div>

              {mockGroup.adIntegration?.isIntegrated && (
                <div>
                  <h3 className="text-lg font-medium mb-4">Active Directory Integration</h3>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-gray-500 mb-1">AD Group Name</p>
                      <p>{mockGroup.adIntegration.adGroupName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Last Sync</p>
                      <p>{mockGroup.adIntegration.lastSync}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'members' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-medium">Current Members</h3>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Add Member
                </button>
              </div>

              <div className="space-y-4">
                {mockGroup.members.map((member, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="font-medium">{member}</p>
                        <p className="text-sm text-gray-500">Added on March 15, 2024</p>
                      </div>
                    </div>
                    <button className="text-red-600 hover:text-red-700">
                      Remove
                    </button>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'pending' && (
            <div>
              <h3 className="text-lg font-medium mb-6">Pending Access Requests</h3>
              <div className="space-y-4">
                {mockPendingRequests.map((request) => (
                  <motion.div
                    key={request.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="font-medium">{request.user}</p>
                        <p className="text-sm text-gray-500">
                          Requested on {request.requestDate}
                        </p>
                        <p className="text-sm text-gray-600 mt-1">
                          {request.justification}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleApproveRequest(request.id)}
                        className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm hover:bg-green-200"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleRejectRequest(request.id)}
                        className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm hover:bg-red-200"
                      >
                        Reject
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'approval-flow' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-medium">Approval Workflow</h3>
                <button
                  onClick={() => {
                    setEditingStep(undefined);
                    setShowModal(true);
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Step
                </button>
              </div>

              <div className="space-y-4">
                {mockApprovalSteps.map((step, index) => (
                  <motion.div
                    key={step.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="relative"
                  >
                    <div className="flex items-start justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          {step.type === 'AND' ? (
                            <Users2 className="w-5 h-5 text-blue-600" />
                          ) : (
                            <UserCog className="w-5 h-5 text-blue-600" />
                          )}
                        </div>
                        <div>
                          <h4 className="font-medium">{step.name}</h4>
                          <p className="text-sm text-gray-500 mt-1">
                            {step.type === 'AND' ? 'All must approve' : 'Any can approve'}
                          </p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {step.approvers.map((approver, i) => (
                              <div
                                key={i}
                                className="flex items-center gap-1 text-xs bg-white px-2 py-1 rounded border"
                              >
                                <Mail className="w-3 h-3 text-gray-500" />
                                {approver}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setEditingStep(step);
                            setShowModal(true);
                          }}
                          className="p-1 hover:bg-gray-200 rounded"
                        >
                          <Settings className="w-4 h-4 text-gray-600" />
                        </button>
                        <button
                          onClick={() => handleDeleteStep(step.id)}
                          className="p-1 hover:bg-gray-200 rounded"
                        >
                          <XCircle className="w-4 h-4 text-red-600" />
                        </button>
                      </div>
                    </div>

                    {index < mockApprovalSteps.length - 1 && (
                      <div className="flex items-center justify-center my-2">
                        <div className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
                          {step.connectionType === 'AND' ? 'AND' : 'AFTER'}
                        </div>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <ApprovalStepModal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingStep(undefined);
        }}
        onSubmit={editingStep ? handleEditStep : handleAddStep}
        step={editingStep}
      />
    </div>
  );
}