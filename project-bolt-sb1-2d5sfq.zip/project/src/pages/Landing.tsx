import React from 'react';
import { 
  Shield, 
  Lock, 
  CheckCircle2, 
  ArrowRight, 
  ChevronRight,
  Users,
  FileCheck,
  Key,
  AlertCircle,
  RefreshCw,
  Fingerprint,
  Building2,
  Award,
  BarChart3
} from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Landing() {
  const features = [
    {
      icon: Lock,
      title: "Gestão de Identidades",
      description: "Controle centralizado de identidades e acessos em toda a organização"
    },
    {
      icon: FileCheck,
      title: "Certificação Automática",
      description: "Processos automatizados de revisão e certificação de acessos"
    },
    {
      icon: Key,
      title: "Governança de Acessos",
      description: "Políticas robustas de controle e monitoramento de privilégios"
    },
    {
      icon: AlertCircle,
      title: "Prevenção de Riscos",
      description: "Identificação proativa de ameaças e vulnerabilidades"
    },
    {
      icon: RefreshCw,
      title: "Integração AD/Azure",
      description: "Sincronização automática com Microsoft Active Directory"
    },
    {
      icon: Fingerprint,
      title: "Autenticação Avançada",
      description: "Suporte a múltiplos fatores de autenticação"
    }
  ];

  const stats = [
    { value: "99.9%", label: "Uptime garantido" },
    { value: "500+", label: "Empresas confiam" },
    { value: "-60%", label: "Redução de riscos" },
    { value: "24/7", label: "Suporte dedicado" }
  ];

  const testimonials = [
    {
      quote: "A implementação do IGA transformou nossa gestão de acessos, tornando-a muito mais segura e eficiente.",
      author: "Maria Silva",
      role: "CISO",
      company: "TechCorp Brasil"
    },
    {
      quote: "Reduzimos drasticamente o tempo de concessão de acessos mantendo total conformidade com as políticas.",
      author: "João Santos",
      role: "Diretor de TI",
      company: "Banco Digital SA"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-gray-900 to-blue-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-blue-600/20" />
        <div className="container mx-auto px-6 py-24">
          <div className="flex flex-col items-center text-center relative z-10">
            <div className="flex items-center gap-2 bg-gray-900/40 px-4 py-2 rounded-full mb-8">
              <span className="bg-blue-400 text-blue-950 text-xs px-2 py-1 rounded-full">Novo</span>
              <span className="text-sm">Certificação automática de acessos</span>
            </div>
            
            <Shield className="w-20 h-20 text-blue-300 mb-8" />
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-200 to-blue-400">
              Identity Governance & Administration
            </h1>
            <p className="text-xl text-blue-100 mb-10 max-w-2xl">
              A plataforma mais completa para gestão de identidades e acessos. 
              Simplifique a governança, reduza riscos e mantenha a conformidade.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Link
                to="/login"
                className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-4 rounded-lg font-medium flex items-center justify-center gap-2 transition-colors text-lg"
              >
                Começar Agora <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/demo"
                className="bg-gray-900 hover:bg-gray-800 text-gray-100 px-8 py-4 rounded-lg font-medium flex items-center justify-center gap-2 transition-colors text-lg border border-gray-700"
              >
                Agendar Demo <ChevronRight className="w-5 h-5" />
              </Link>
            </div>

            <div className="flex items-center gap-8 text-gray-200">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-10 h-10 rounded-full bg-gray-800 border-2 border-gray-900" />
                ))}
              </div>
              <p className="text-sm">
                +1000 empresas já utilizam nossa plataforma
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Segurança e Conformidade em Primeiro Lugar</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Nossa plataforma oferece recursos avançados para garantir a segurança
              e conformidade da sua organização.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="p-6 border border-gray-100 rounded-xl hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gray-900 py-16">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <p className="text-4xl font-bold text-blue-400 mb-2">{stat.value}</p>
                <p className="text-gray-300">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Quem Usa, Aprova</h2>
            <p className="text-gray-600">Conheça a experiência de nossos clientes</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-xl">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Building2 className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-gray-700 mb-4">{testimonial.quote}</p>
                    <p className="font-semibold">{testimonial.author}</p>
                    <p className="text-sm text-gray-600">{testimonial.role} • {testimonial.company}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Certifications Section */}
      <div className="bg-gray-50 py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Certificações e Compliance</h2>
            <p className="text-gray-600">
              Nossa plataforma atende aos mais rigorosos padrões de segurança
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {['ISO 27001', 'SOC 2', 'LGPD', 'NIST'].map((cert, index) => (
              <div key={index} className="flex flex-col items-center p-6 bg-white rounded-xl border border-gray-100">
                <Award className="w-12 h-12 text-blue-600 mb-4" />
                <p className="font-semibold">{cert}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 py-16">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-8">
            Pronto para transformar a segurança da sua empresa?
          </h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/demo"
              className="bg-white text-blue-600 px-8 py-4 rounded-lg font-medium inline-flex items-center justify-center gap-2 hover:bg-gray-100 transition-colors"
            >
              Agendar Demonstração <BarChart3 className="w-5 h-5" />
            </Link>
            <Link
              to="/login"
              className="bg-blue-900 text-white px-8 py-4 rounded-lg font-medium inline-flex items-center justify-center gap-2 hover:bg-blue-800 transition-colors"
            >
              Criar Conta <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}