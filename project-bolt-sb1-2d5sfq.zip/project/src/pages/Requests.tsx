import React, { useState } from 'react';
import { Plus, Search } from 'lucide-react';
import AccessRequestModal from '../components/AccessRequestModal';

const mockGroups = [
  { id: '1', name: 'Finance Team' },
  { id: '2', name: 'HR Department' },
  { id: '3', name: 'IT Support' },
];

export default function Requests() {
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [filter, setFilter] = useState('all');

  const handleRequestSubmit = (groupId: string, justification: string) => {
    console.log('Access requested:', { groupId, justification });
    // Here you would typically make an API call to submit the request
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Access Requests</h1>
        <button
          onClick={() => setShowRequestModal(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          New Request
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-4 border-b">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="search"
                placeholder="Search requests..."
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Requests</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>

        <div className="p-4">
          <table className="w-full">
            <thead>
              <tr className="text-left text-sm text-gray-500">
                <th className="pb-4">Request ID</th>
                <th className="pb-4">Group</th>
                <th className="pb-4">Submitted</th>
                <th className="pb-4">Status</th>
                <th className="pb-4">Actions</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {[1, 2, 3].map((i) => (
                <tr key={i} className="border-t">
                  <td className="py-4">REQ-{i.toString().padStart(4, '0')}</td>
                  <td className="py-4">Finance Team</td>
                  <td className="py-4">2024-03-10</td>
                  <td className="py-4">
                    <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs">
                      Pending
                    </span>
                  </td>
                  <td className="py-4">
                    <button className="text-blue-600 hover:underline">
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showRequestModal && (
        <AccessRequestModal
          onClose={() => setShowRequestModal(false)}
          onSubmit={handleRequestSubmit}
          groups={mockGroups}
        />
      )}
    </div>
  );
}