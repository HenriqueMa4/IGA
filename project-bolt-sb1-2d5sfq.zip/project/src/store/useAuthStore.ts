import { create } from 'zustand';

interface User {
  id: string;
  email: string;
  name: string;
}

interface AuthState {
  user: User | null;
  login: (email: string, password: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  login: (email, password) => {
    // Simulate authentication
    const user = {
      id: '1',
      email,
      name: email.includes('admin') ? 'Admin User' : 'Regular User',
    };
    set({ user });
  },
  logout: () => set({ user: null }),
}));