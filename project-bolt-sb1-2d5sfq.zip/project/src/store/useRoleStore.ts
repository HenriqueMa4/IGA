import { create } from 'zustand';

type Role = 'admin' | 'user';

interface RoleState {
  role: Role;
  setRole: (role: Role) => void;
}

export const useRoleStore = create<RoleState>((set) => ({
  role: 'admin',
  setRole: (role) => set({ role }),
}));