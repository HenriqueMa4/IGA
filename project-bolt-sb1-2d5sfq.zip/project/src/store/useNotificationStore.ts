import { create } from 'zustand';

interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'groups' | 'requests' | 'certifications';
  read: boolean;
}

interface NotificationState {
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'read'>) => void;
  markAsRead: (id: string) => void;
  getNotificationCount: (type: string) => number;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [
    {
      id: '1',
      title: 'New Access Request',
      message: 'John Doe requested access to Finance Team',
      time: '5 min ago',
      type: 'requests',
      read: false,
    },
    {
      id: '2',
      title: 'Certification Due',
      message: 'Quarterly access review is due in 2 days',
      time: '1 hour ago',
      type: 'certifications',
      read: false,
    },
    {
      id: '3',
      title: 'Group Update',
      message: 'HR Department group has been modified',
      time: '2 hours ago',
      type: 'groups',
      read: false,
    },
  ],
  addNotification: (notification) =>
    set((state) => ({
      notifications: [
        {
          ...notification,
          id: Math.random().toString(36).substr(2, 9),
          read: false,
        },
        ...state.notifications,
      ],
    })),
  markAsRead: (id) =>
    set((state) => ({
      notifications: state.notifications.map((n) =>
        n.id === id ? { ...n, read: true } : n
      ),
    })),
  getNotificationCount: (type) => {
    const { notifications } = get();
    return notifications.filter((n) => n.type === type && !n.read).length;
  },
}));