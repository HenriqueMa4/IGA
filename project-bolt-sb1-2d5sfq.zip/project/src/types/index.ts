export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  groups: string[];
}

export interface Group {
  id: string;
  name: string;
  description: string;
  members: string[];
  approvers: string[];
  status: 'pending' | 'active' | 'rejected';
  adIntegration?: {
    isIntegrated: boolean;
    adGroupName?: string;
    lastSync?: string;
  };
  approvalStatus: {
    requiredApprovals: number;
    approvedBy: Array<{
      adminId: string;
      adminName: string;
      date: string;
    }>;
    rejectedBy: Array<{
      adminId: string;
      adminName: string;
      date: string;
      reason: string;
    }>;
  };
  createdBy: {
    id: string;
    name: string;
    date: string;
  };
}