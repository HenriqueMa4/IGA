import React, { useState } from 'react';
import { X, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Group } from '../types';

interface GroupApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  group: Group;
  onApprove: (groupId: string) => void;
  onReject: (groupId: string, reason: string) => void;
}

export default function GroupApprovalModal({
  isOpen,
  onClose,
  group,
  onApprove,
  onReject,
}: GroupApprovalModalProps) {
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectForm, setShowRejectForm] = useState(false);

  if (!isOpen) return null;

  const handleApprove = () => {
    onApprove(group.id);
    onClose();
  };

  const handleReject = (e: React.FormEvent) => {
    e.preventDefault();
    onReject(group.id, rejectReason);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-2xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Group Approval Review</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium mb-2">Group Details</h3>
            <div className="space-y-2">
              <p><span className="text-gray-600">Name:</span> {group.name}</p>
              <p><span className="text-gray-600">Description:</span> {group.description}</p>
              <p><span className="text-gray-600">Created by:</span> {group.createdBy.name}</p>
              <p><span className="text-gray-600">Created on:</span> {group.createdBy.date}</p>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium mb-2">Approval Status</h3>
            <div className="flex items-center gap-2 mb-4">
              <AlertCircle className="w-5 h-5 text-yellow-600" />
              <span>
                {group.approvalStatus.approvedBy.length} of {group.approvalStatus.requiredApprovals} required approvals
              </span>
            </div>
            
            {group.approvalStatus.approvedBy.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Approved by:</h4>
                {group.approvalStatus.approvedBy.map((approval) => (
                  <div key={approval.adminId} className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>{approval.adminName}</span>
                    <span>on {approval.date}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {!showRejectForm ? (
            <div className="flex justify-end gap-2 pt-4 border-t">
              <button
                onClick={() => setShowRejectForm(true)}
                className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2"
              >
                <XCircle className="w-5 h-5 text-red-600" />
                Reject
              </button>
              <button
                onClick={handleApprove}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
              >
                <CheckCircle className="w-5 h-5" />
                Approve
              </button>
            </div>
          ) : (
            <form onSubmit={handleReject} className="pt-4 border-t">
              <label className="block text-sm font-medium mb-2">
                Rejection Reason
              </label>
              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                rows={3}
                required
                placeholder="Please provide a reason for rejecting this group..."
              />
              <div className="flex justify-end gap-2 mt-4">
                <button
                  type="button"
                  onClick={() => setShowRejectForm(false)}
                  className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}