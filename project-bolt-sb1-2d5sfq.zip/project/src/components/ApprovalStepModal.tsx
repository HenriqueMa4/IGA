import React, { useState, useEffect } from 'react';
import { X, Plus, XCircle, Users2, UserCog } from 'lucide-react';

type ApprovalType = 'AND' | 'OR';

interface ApprovalStep {
  id: string;
  type: ApprovalType;
  approvers: string[];
  name: string;
  connectionType?: 'AND' | 'AFTER';
}

interface ApprovalStepModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (step: Omit<ApprovalStep, 'id'>) => void;
  step?: ApprovalStep;
}

export default function ApprovalStepModal({ isOpen, onClose, onSubmit, step }: ApprovalStepModalProps) {
  const [formData, setFormData] = useState<Omit<ApprovalStep, 'id'>>({
    type: 'AND',
    approvers: [''],
    name: '',
    connectionType: 'AND'
  });

  useEffect(() => {
    if (step) {
      setFormData({
        type: step.type,
        approvers: step.approvers,
        name: step.name,
        connectionType: step.connectionType
      });
    } else {
      setFormData({
        type: 'AND',
        approvers: [''],
        name: '',
        connectionType: 'AND'
      });
    }
  }, [step]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      approvers: formData.approvers.filter(Boolean)
    });
    onClose();
  };

  const addApprover = () => {
    setFormData(prev => ({
      ...prev,
      approvers: [...prev.approvers, '']
    }));
  };

  const removeApprover = (index: number) => {
    setFormData(prev => ({
      ...prev,
      approvers: prev.approvers.filter((_, i) => i !== index)
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-lg">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              {formData.type === 'AND' ? (
                <Users2 className="w-5 h-5 text-blue-600" />
              ) : (
                <UserCog className="w-5 h-5 text-blue-600" />
              )}
            </div>
            <h2 className="text-xl font-bold">
              {step ? 'Edit Approval Step' : 'Add Approval Step'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">Step Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., Management Approval"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Approval Type</label>
            <select
              value={formData.type}
              onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value as ApprovalType }))}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="AND">ALL must approve (AND)</option>
              <option value="OR">ANY can approve (OR)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Approvers</label>
            <div className="space-y-2">
              {formData.approvers.map((approver, index) => (
                <div key={index} className="flex gap-2">
                  <input
                    type="email"
                    value={approver}
                    onChange={(e) => {
                      const newApprovers = [...formData.approvers];
                      newApprovers[index] = e.target.value;
                      setFormData(prev => ({ ...prev, approvers: newApprovers }));
                    }}
                    className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="approver@example.com"
                    required
                  />
                  {formData.approvers.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeApprover(index)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={addApprover}
                className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                Add Approver
              </button>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              {step ? 'Update Step' : 'Add Step'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}