import React from 'react';
import { useRoleStore } from '../store/useRoleStore';
import { Shield, User } from 'lucide-react';

export default function RoleSwitcher() {
  const { role, setRole } = useRoleStore();

  return (
    <div className="fixed top-0 left-0 right-0 h-12 bg-gray-900 z-20 px-4 flex items-center justify-center gap-4 border-b border-gray-700">
      <button
        onClick={() => setRole('admin')}
        className={`flex items-center gap-2 px-4 py-1.5 rounded-lg transition-colors ${
          role === 'admin'
            ? 'bg-blue-600 text-white'
            : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
        }`}
      >
        <Shield className="w-4 h-4" />
        <span className="font-medium">Gestor</span>
      </button>
      
      <button
        onClick={() => setRole('user')}
        className={`flex items-center gap-2 px-4 py-1.5 rounded-lg transition-colors ${
          role === 'user'
            ? 'bg-blue-600 text-white'
            : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
        }`}
      >
        <User className="w-4 h-4" />
        <span className="font-medium">Usuário</span>
      </button>
    </div>
  );
}