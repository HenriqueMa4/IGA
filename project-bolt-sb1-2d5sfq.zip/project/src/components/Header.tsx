import React, { useState } from 'react';
import { Bell, User, X } from 'lucide-react';
import { useRoleStore } from '../store/useRoleStore';
import { useNotificationStore } from '../store/useNotificationStore';

export default function Header() {
  const { role } = useRoleStore();
  const { notifications } = useNotificationStore();
  const [showNotifications, setShowNotifications] = useState(false);
  
  return (
    <header className="h-16 bg-gray-900 fixed top-0 right-0 left-64 z-10 px-6 flex items-center justify-end">
      <div className="flex items-center gap-6">
        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-full hover:bg-gray-800 text-gray-300 hover:text-white transition-colors"
          >
            <Bell className="w-6 h-6" />
            {notifications.length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center text-white">
                {notifications.length}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg py-2 text-gray-900">
              <div className="flex items-center justify-between px-4 py-2 border-b">
                <h3 className="font-semibold">Notifications</h3>
                <button 
                  onClick={() => setShowNotifications(false)}
                  className="p-1 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="max-h-96 overflow-y-auto">
                {notifications.length > 0 ? (
                  notifications.map((notification) => (
                    <div 
                      key={notification.id} 
                      className="px-4 py-3 hover:bg-gray-50 border-b last:border-b-0"
                    >
                      <p className="text-sm font-medium">{notification.title}</p>
                      <p className="text-xs text-gray-600 mt-1">{notification.message}</p>
                      <span className="text-xs text-gray-500 mt-1">{notification.time}</span>
                    </div>
                  ))
                ) : (
                  <div className="px-4 py-3 text-sm text-gray-600">
                    No new notifications
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-3 p-2 rounded-full hover:bg-gray-800 cursor-pointer text-gray-300 hover:text-white transition-colors">
          <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center">
            <User className="w-5 h-5" />
          </div>
          <span className="font-medium">{role === 'admin' ? 'Gestor' : 'Usuário'}</span>
        </div>
      </div>
    </header>
  );
}