import React, { useState } from 'react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import { useRoleStore } from '../store/useRoleStore';
import { useNotificationStore } from '../store/useNotificationStore';
import { useAuthStore } from '../store/useAuthStore';
import { 
  Users, 
  Shield, 
  Settings, 
  UserCircle, 
  History,
  CheckCircle2,
  FolderOpen,
  User,
  Bell,
  LogOut
} from 'lucide-react';

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { role, setRole } = useRoleStore();
  const { notifications } = useNotificationStore();
  const { getNotificationCount } = useNotificationStore();
  const { logout, user } = useAuthStore();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const isActive = (path: string) => location.pathname === path;
  const isAdmin = user?.email.includes('admin');

  const handleLogout = () => {
    logout();
    setRole('admin');
    navigate('/');
  };

  const adminMenuItems = [
    { path: '/dashboard', icon: UserCircle, label: 'Dashboard' },
    { path: '/groups', icon: Users, label: 'Groups', notifications: getNotificationCount('groups') },
    { path: '/requests', icon: History, label: 'Access Requests', notifications: getNotificationCount('requests') },
    { path: '/certifications', icon: CheckCircle2, label: 'Certifications', notifications: getNotificationCount('certifications') },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  const userMenuItems = [
    { path: '/my-access', icon: FolderOpen, label: 'My Access' },
    { path: '/requests', icon: History, label: 'My Requests', notifications: getNotificationCount('requests') },
  ];

  const menuItems = role === 'admin' ? adminMenuItems : userMenuItems;
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="h-screen w-64 bg-gray-900 text-white fixed left-0 top-0 flex flex-col">
      <div className="p-4">
        <h1 className="text-2xl font-bold flex items-center gap-2 mb-6">
          <Shield className="w-8 h-8 text-blue-400" />
          <span>IGA System</span>
        </h1>

        {isAdmin && (
          <div className="flex gap-2 mb-8">
            <button
              onClick={() => setRole('admin')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg transition-colors ${
                role === 'admin'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-800 text-gray-200 hover:bg-gray-700'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span className="font-medium">Gestor</span>
            </button>
            
            <button
              onClick={() => setRole('user')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg transition-colors ${
                role === 'user'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-800 text-gray-200 hover:bg-gray-700'
              }`}
            >
              <User className="w-4 h-4" />
              <span className="font-medium">Usuário</span>
            </button>
          </div>
        )}
      </div>
      
      <nav className="flex-1">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center justify-between px-4 py-3 hover:bg-gray-800 transition-colors ${
              isActive(item.path) ? 'bg-gray-800 border-l-4 border-blue-400' : ''
            }`}
          >
            <div className="flex items-center gap-3">
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </div>
            {item.notifications > 0 && (
              <span className="bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {item.notifications}
              </span>
            )}
          </Link>
        ))}
      </nav>

      <div className="p-4 border-t border-gray-800">
        <div className="relative">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="w-full flex items-center gap-3 bg-gray-800 p-3 rounded-lg hover:bg-gray-700 transition-colors"
          >
            <div className="relative">
              <Bell className="w-6 h-6 text-gray-200" />
              {unreadCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-gray-200" />
              </div>
              <span className="font-medium text-gray-200">
                {role === 'admin' ? 'Gestor' : 'Usuário'}
              </span>
            </div>
          </button>

          {showProfileMenu && (
            <button
              onClick={handleLogout}
              className="absolute bottom-full left-0 right-0 mb-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors w-full"
            >
              <LogOut className="w-4 h-4" />
              <span className="font-medium">Sair</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}