import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Groups from './pages/Groups';
import GroupDetails from './pages/GroupDetails';
import Requests from './pages/Requests';
import Certifications from './pages/Certifications';
import Settings from './pages/Settings';
import MyAccess from './pages/MyAccess';
import Landing from './pages/Landing';
import Login from './pages/Login';
import DemoRequest from './pages/DemoRequest';
import { useRoleStore } from './store/useRoleStore';
import { useAuthStore } from './store/useAuthStore';

function App() {
  const { role } = useRoleStore();
  const { user } = useAuthStore();

  if (!user) {
    return (
      <Router>
        <Toaster position="top-right" />
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/demo" element={<DemoRequest />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    );
  }

  return (
    <Router>
      <Toaster position="top-right" />
      <div className="min-h-screen bg-gray-50">
        <Sidebar />
        
        <main className="ml-64 p-8">
          <Routes>
            {role === 'admin' ? (
              <>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/groups" element={<Groups />} />
                <Route path="/groups/:id" element={<GroupDetails />} />
                <Route path="/requests" element={<Requests />} />
                <Route path="/certifications" element={<Certifications />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
              </>
            ) : (
              <>
                <Route path="/my-access" element={<MyAccess />} />
                <Route path="/requests" element={<Requests />} />
                <Route path="*" element={<Navigate to="/my-access" replace />} />
              </>
            )}
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;